
var MAP_API = {

	AVIATION_API_URL: "http://api.aviationstack.com/v1/airports?access_key=6cdfdcbda57de4d10a8a94a8ee798a59",

	map : null,
	airports: null,

	initMap : function () {

		this.buildMap();
		this.fetchData();
	},

	buildMap : function () {

		// TODO
		// initialiser la google map
	},

	fetchData : function () {

		// TODO
		// recuperer les donnees de l'API
	},

	appendElementToList : function ( airport ) {

		// TODO
		// ajouter les elements a la liste
	}
}
